# Suplemento-do-Bombas
Familia unida, quando forem mandar o arquivo com as imagens, compacta a pasta inteira e manda, ganha ponto extra comigo se só compactar todos os arquivos e der upload, fica mais simples.

Jean, vai olhar o que dá ponto extra e procura algum deles para fazer, não faz todos, já que vão ter mais páginas, e não queremos sobrecarga de informação.

Os arquivos estão meio bagunçados agora também, a gente vai arrumar, eu acho que só o jean consegue apagar os arquivos então a gente só pode esperar mesmo.
